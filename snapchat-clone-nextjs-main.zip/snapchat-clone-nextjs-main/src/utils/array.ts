export const randomArrayVal = (arr: any[]) => arr[Math.floor(Math.random() * arr.length)];

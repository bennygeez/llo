'use client'
import React, { ReactNode, useEffect } from 'react';
import { useDispatch } from 'react-redux';
import { getSession, getFriends } from '@/app/features/User/UserStore';
import Header from '@/components/Header';
import Toolbar from './ToolBar';
import Drawer from './Drawer';
import Footer from './Footer';
import { getPhotos } from '@/app/features/Camera/CameraStore';
const AppShell= ({ children }:{
    children: ReactNode
}) => {
    const dispatch = useDispatch();

    // Init the app
    useEffect(() => {
        dispatch(getSession() as any);
        dispatch(getFriends() as any);
        dispatch(getPhotos() as any);
    }, []);

    return (
        <>
            <Toolbar />
            <Header />
            <section className="view">{children}</section>
            <Drawer />
            <Footer />
        </>
    );
};

export default AppShell;

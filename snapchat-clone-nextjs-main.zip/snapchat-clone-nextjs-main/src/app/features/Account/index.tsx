import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { hideDrawer } from '@/app/blocks/appShellStore';
import { language } from '@/utils';
import Button from '@/components/Button';
import Section from '@/components/Section';
import MenuItem from '@/components/MenuItem';
import Icon from '@/components/Icon';
import Map from './Map';
import { Logo } from './Logo.svg';
import './Account.scss';

const currentDate = new Date().toLocaleDateString(language, {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
});

const Account: React.FC = () => {
    const dispatch = useDispatch();
    const {
        session: { username }
    } = useSelector(({ user }: any) => user);

    return (
        <main className="account">
            <header>
                <Button
                    icon="faAngleDown"
                    onClick={() => dispatch(hideDrawer('account'))}
                    className="btn-close"
                />
                <Icon name="faCog" className="ico-gear" />
            </header>
            <div className="logo">
                <Logo />
                <strong>{username}</strong>
            </div>
            <Section header="Stories" transparent>
                <MenuItem leftIcon="faCamera" rightIcon="faEllipsisV" label="Add to My Story" />
                <MenuItem leftIcon="faCamera" rightIcon="faEllipsisV" label="Add to Our Story" />
            </Section>
            <Section header="Friends" transparent>
                <MenuItem leftIcon="faUserPlus" rightIcon="faAngleRight" label="Add Friends" />
                <MenuItem leftIcon="faListAlt" rightIcon="faAngleRight" label="My Friends" />
            </Section>
            <Section header="Bitmoji" transparent>
                <MenuItem leftIcon="faGrinBeam" rightIcon="faAngleRight" label="Create Bitmoji" />
            </Section>
            <Section header="Snap Map">
                <Map />
                <MenuItem
                    leftIcon="faCompass"
                    rightIcon="faAngleRight"
                    label="Set a Status"
                    straightEdge
                />
            </Section>
            <footer>
                <p>
                    <a
                        href="https://github.com/TowhidKashem/snapchat-clone"
                        target="_blank"
                        rel="noopener noreferrer"
                        title="Github Repo"
                    >
                        <Icon name="faGithub" />
                    </a>
                    Joined Snapchat on {currentDate}
                </p>
            </footer>
        </main>
    );
};

export default Account;

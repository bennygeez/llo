'use client'
import React from 'react'
import AppShell from "./blocks/appShell";
import { Provider } from "react-redux";
import { configureStore } from '@reduxjs/toolkit';

import app from './blocks/appShellStore';
import camera from '@/app/features/Camera/CameraStore';
import user from '@/app/features/User/UserStore';
import snapMap from '@/app/features/SnapMap/SnapMapStore';
import snap from '@/app/features/Snap/SnapStore';
import chat from '@/app/features/Chat/ChatStore';

function Client({children}:{
    children: React.ReactNode
}) {
    const store = configureStore({
        reducer: { app, camera, user, snapMap, snap, chat }
    });
  return (
      <Provider
          store={store}
      >
          <AppShell>

              {children}
          </AppShell>
      </Provider>
  )
}

export default Client
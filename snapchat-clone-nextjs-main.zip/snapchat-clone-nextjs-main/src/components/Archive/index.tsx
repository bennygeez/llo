import React from 'react';
import { useSelector, useDispatch} from 'react-redux';
import { showDrawer } from '@/app/blocks/appShellStore';
import { addSnap } from '@/app/features/Snap/SnapStore';
import { Photo } from '@/app/features/Camera/data';
import Header from '../Header';
import Button from '../Button';
import Loader from '../Loader';
import Error from 'next/error';
import './Archive.scss';

const Archive: React.FC = () => {
    const dispatch = useDispatch();
    const { photos, photoTaken } = useSelector(({ camera }: any) => camera);

    const openPhoto = (image: string) => {
        dispatch(
            addSnap({
                type: 'photo',
                url: image,
                shareable: true
            })
        );
        dispatch(
            showDrawer({
                component: 'snap',
                animationIn: 'zoomIn',
                animationOut: 'zoomOut',
                theme: 'dark'
            })
        );
    };

    return (
        <main className="archive">
            <Header insideDrawer />

            {photos.loading ? (
                <Loader nobg />
            ) : photos.error ? (
                <Error/>
            ) : (
                <>
                    <nav className="view-options">
                        <Button label="Snaps" className="active" />
                        <Button label="Camera Roll" />
                    </nav>

                    {!photoTaken && (
                        <section className="message" data-test="placeholder-msg">
                            <p>Take a photo and it will appear here!</p>
                        </section>
                    )}

                    {photos.data.map(({ month, year, images }: Photo, index: number) => (
                        <section key={month + index} className="month" data-test="month">
                            <h3>
                                {month} {year}
                            </h3>
                            {images.map((image, index) => (
                                <img
                                    key={image + index}
                                    src={image}
                                    width={100}
                                    alt=""
                                    onClick={() => openPhoto(image)}
                                    data-test="snap-image"
                                />
                            ))}
                        </section>
                    ))}
                </>
            )}
        </main>
    );
};

export default Archive;
